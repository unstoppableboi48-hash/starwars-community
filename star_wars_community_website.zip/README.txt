STAR WARS COMMUNITY / FAN HUB WEBSITE

To preview:
1. Open index.html in a web browser.

To publish free:
1. Create a GitHub account and a new public repository.
2. Upload index.html to the repository's main/root folder.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose the main branch and / (root), then Save.
6. GitHub Pages will provide a public website link after deployment.

The Discord invite is already connected to the Join Our Discord! buttons:
https://discord.gg/sWVBPzjQpJ

Edit index.html to change the website text, rules, colors, or links.
